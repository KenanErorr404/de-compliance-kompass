# Standard Operating Procedure (SOP): Sicherer Release- & Update-Prozess nach BSI TR-03185

- **Dokumenten-ID:** SOP-SEC-TR03185-2026
- **Version:** 1.0 (Stand: Oktober 2026)
- **Geltungsbereich:** Alle Engineering-, DevSecOps-, QA- und Produktmanagement-Teams
- **Regulatorische Referenz:** BSI TR-03185 („Sicherer Software-Lebenszyklus“), BSI TR-03161 (DiGA), ISO/IEC 27001, NIS-2 (§ 30 BSIG)

---

## 1. Zielsetzung und Zweck

Diese Standard Operating Procedure (SOP) definiert das verbindliche Verfahren für die Planung, Verifikation, Freigabe und Auslieferung von Software-Updates. Ziel ist es, die Anforderungen der **BSI TR-03185** vollständig zu erfüllen, sodass Sicherheits-Updates, Dependency-Patches und funktionale Weiterentwicklungen **ohne Verlust einer bestehenden Produktzertifizierung und ohne manuelle Re-Zertifizierungsschleife** in den Produktivbetrieb überführt werden können.

---

## 2. Verbindliche Änderungs-Klassifikation (Change Impact Assessment)

Jeder Pull Request bzw. jedes Release-Ticket muss vor dem Merge in den Release-Zweig einer der folgenden drei Änderungsklassen zugeordnet werden:

| Änderungsklasse | Definition | Auswirkung auf bestehende BSI-Zertifizierung | Erforderliche Freigabe |
| :--- | :--- | :--- | :--- |
| **Klasse A – Security- & Dependency-Patch** | Reine Fehlerbehebung oder Aktualisierung von Drittbibliotheken ohne Änderung an Sicherheitsfunktionen (SFRs), APIs oder Datenflüssen. | **Zertifizierung bleibt vollständig erhalten** (automatisierter Nachweis via CI/CD). | Automatisiertes Security-Gate + Lead Developer |
| **Klasse B – Funktionales Minor-Update** | Neue oder angepasste Fachfunktionen, die ausschließlich bestehende, bereits geprüfte Sicherheitsmechanismen (IAM, Kryptographie, Logging) nutzen. | **Zertifizierung bleibt im Rahmen des TR-03185-Prozesses erhalten.** | Product Security Officer (PSO) + QA-Sign-off |
| **Klasse C – Architektur- / SFR-Änderung** | Änderungen an Authentifizierung, Autorisierung, Kryptographie (TR-02102), Mandantentrennung oder externen Vertrauensgrenzen. | **Formales Delta-Review / Einbindung der Prüfstelle erforderlich.** | CISO + Product Security Officer + Externe Prüfstelle |

---

## 3. Verbindliche CI/CD-Verifikationsschritte vor jedem Release

Kein Release-Artefakt darf erstellt oder veröffentlicht werden, ohne dass folgende automatisierte Pipeline-Stufen fehlerfrei (`PASS`) durchlaufen wurden:

1. **Quellcode- & Commit-Integrität:**
   - Alle Commits im Release-Scope sind kryptographisch signiert (SSH/GPG).
   - Mindestens ein unabhängiges Vier-Augen-Review liegt für jeden Merge vor.
2. **Statische & Dynamische Sicherheitsprüfung:**
   - **SAST & Secret-Scanning:** 0 offene Befunde der Kategorien *Critical* oder *High*.
   - **SCA & SBOM-Erzeugung:** Erzeugung einer aktuellen `sbom.cdx.json` (CycloneDX 1.5+). Keine bekannten ausnutzbaren CVEs mit CVSS ≥ 7.0 ohne dokumentierte VEX-Freigabe.
   - **DAST / API-Security-Tests:** Erfolgreicher Durchlauf gegen die Staging-Umgebung.
3. **Automatisierte Security-Regression-Suite:**
   - 100 % Pass-Rate aller automatisierten Tests für Sicherheitsfunktionen (Zugriffskontrolle, Session-Invalidierung, TLS-/Krypto-Konfiguration, Audit-Logging).
4. **Reproduzierbarer Build & Signierung:**
   - Ausführung auf isolierten, ephemeren Build-Runnern.
   - Kryptographische Signierung des Artefakts/Container-Images und Speicherung der Build-Provenance.

---

## 4. Erstellung und Archivierung des Release-Evidence-Bundles

Für jedes veröffentlichte Release (`vX.Y.Z`) legt die CI/CD-Pipeline automatisch ein unveränderliches **Evidence-Bundle** im Audit-Archiv ab:

- `01_Change_Impact_Assessment.json` (Einstufung Klasse A/B/C inkl. Begründung)
- `02_SBOM_and_VEX_Report.json` (Vollständige Komponentenliste & Schwachstellenstatus)
- `03_Security_Gate_Results.sarif` (Konsolidierte SAST/DAST/SCA-Ergebnisse)
- `04_Security_Regression_Test_Report.xml` (Nachweis der unversehrten Sicherheitsfunktionen)
- `05_Artifact_Signatures_and_Hashes.txt` (SHA-256 Prüfsummen & Signatur-Verifikation)

---

## 5. Formale Freigabeerklärung (Sign-Off-Vorlage)

```text
RELEASE-KONFORMITÄTSVERMERK GEMÄSS BSI TR-03185
------------------------------------------------
Produkt / Komponente : [Name der Anwendung / DiGA / SaaS-Plattform]
Release-Version      : [vX.Y.Z]
Datum (UTC)          : [YYYY-MM-DD]
Änderungsklasse      : [ ] Klasse A   [ ] Klasse B   [ ] Klasse C
Git-Commit / Tag     : [SHA-Commit-Hash]
SBOM-Referenz        : [Datei / Prüfsumme]

Bestätigung: Hiermit wird bestätigt, dass das oben genannte Release
vollständig gemäß den Vorgaben der BSI TR-03185 entwickelt, automatisiert
verifiziert und ohne offene kritische Sicherheitsmängel freigegeben wurde.

Freigabe durch Product Security Officer: ___________________________
```
