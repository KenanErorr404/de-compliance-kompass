# Executive Migrationsplan (2026–2031): Post-Quanten-Kryptographie nach BSI TR-02102, Art. 32 DSGVO & NIS-2

- **Dokumenten-ID:** PQC-ROADMAP-TR02102-2026
- **Zielgruppe:** Geschäftsführung, CISO, IT-Leitung, Datenschutzbeauftragte (DSB), Compliance & Audit
- **Regulatorische Basis:** BSI TR-02102-1 bis -4 (Stand 2026), Art. 32 DSGVO („Stand der Technik“), § 30 BSIG (NIS-2-Risikomanagementmaßnahmen)

---

## 1. Management Summary: Warum das Ablaufdatum 2031 heute budget- und haftungsrelevant ist

Mit der Aktualisierung der Technischen Richtlinie **BSI TR-02102-1** hat das Bundesamt für Sicherheit in der Informationstechnik (BSI) erstmals ein verbindliches Ablaufdatum für den alleinigen Einsatz klassischer asymmetrischer Verschlüsselungsverfahren (RSA, Diffie-Hellman, ECDH) festgelegt: **Spätestens ab Ende 2031 müssen Schlüsselaushandlungs- und Public-Key-Verschlüsselungsverfahren zwingend im Hybrid-Modus mit Post-Quanten-Kryptographie (PQC) betrieben werden.** Für rein klassische digitale Signaturen gilt eine Übergangsfrist bis **2035**.

Da Angreifer bereits heute verschlüsselte Datenströme aufzeichnen (**„Harvest Now, Decrypt Later“**), unterliegen alle Geschäftsgeheimnisse, personenbezogenen Daten (Art. 9 DSGVO) und Finanzdaten mit einer Schutzbedarfsdauer von ≥ 5 Jahren bereits im Jahr **2026** einem unmittelbaren Kompromittierungsrisiko. Zudem verlangen sowohl **Art. 32 DSGVO** als auch **§ 30 BSIG (NIS-2)** die Umsetzung von Verschlüsselungskonzepten nach dem aktuellen **Stand der Technik**.

---

## 2. Regulatorisches Mapping für interne und externe Audits

| Rechtsnorm / Standard | Konkrete Anforderung | Bedeutung des BSI TR-02102 Updates (2026) für den Prüfnachweis |
| :--- | :--- | :--- |
| **Art. 32 Abs. 1 lit. a DSGVO** | Verschlüsselung personenbezogener Daten unter Berücksichtigung des Stands der Technik | Ohne dokumentiertes Krypto-Inventar und PQC-Migrationspfad bis 2031 droht bei langlebigen Daten (Gesundheit, HR, Finanzen) ein Verstoß gegen den Stand der Technik. |
| **§ 30 Abs. 2 Nr. 8 BSIG (NIS-2)** | Konzepte und Verfahren für den Einsatz von Kryptographie und Verschlüsselung | Geschäftsleiterpflicht: Nachweis von Krypto-Agilität, Lebenszyklus-Management kryptographischer Schlüssel und PQC-Roadmap. |
| **BSI TR-02102-1 / -2 / -3 / -4** | Einsatz hybrider Schlüsselaushandlung (Klassik + PQC-KEM) bis spätestens Ende 2031 | Technische Referenz für TLS 1.3 (TR-02102-2), IPsec/IKEv2 (TR-02102-3) und SSH (TR-02102-4). |

---

## 3. Die 4-Phasen-Migrations-Roadmap (2026–2031)

### Phase 1: Discovery & Cryptographic Bill of Materials (CBOM) [Q4 2026 – Q2 2027]
- **Meilenstein 1.1:** Vollständige Befüllung des Krypto-Inventars (`Krypto-Inventar-PQC-2031.csv`) für alle externen und internen Schnittstellen, VPN-Gateways, SSH-Server, Datenbanken und PKI-/HSM-Systeme.
- **Meilenstein 1.2:** Identifikation aller Datenbestände mit Vertraulichkeitsanforderung über das Jahr 2031 hinaus (Priorisierung nach „Harvest Now, Decrypt Later“-Exposition).
- **Meilenstein 1.3:** Lieferanten-Abfrage (Vendor Readiness Check) bei Cloud-, Firewall-, VPN- und HSM-Herstellern bzgl. RFC 9370 (IKEv2 PQC), TLS 1.3 Hybrid KeyShares und FIPS 203/204/205.

### Phase 2: Krypto-Agilität & Quick-Win-Pilotierung [Q3 2027 – Q4 2028]
- **Meilenstein 2.1 (SSH nach TR-02102-4):** Flächendeckendes Upgrade auf OpenSSH ≥ 9.9 und Aktivierung von `mlkem768x25519-sha256` als primärem Schlüsselaustausch.
- **Meilenstein 2.2 (TLS 1.3 nach TR-02102-2):** Aktivierung hybrider PQC-Gruppen (`SecP256r1MLKEM768` / `X25519MLKEM768` / `FrodoKEM`) auf produktiven Reverse-Proxies und API-Gateways.
- **Meilenstein 2.3 (Code-Sanierung):** Beseitigung hartcodierter RSA/ECC-Aufrufe und starrer Puffergrößen für Schlüssel/Zertifikate in Eigenentwicklungen.

### Phase 3: Kernnetzwerk-, VPN- & PKI-/HSM-Transformation [2029 – Q2 2030]
- **Meilenstein 3.1 (IPsec/IKEv2 nach TR-02102-3):** Umstellung aller Site-to-Site-VPN-Strecken auf hybride IKEv2-Schlüsselaushandlung (RFC 9370 Multiple Key Exchanges mit ECDH + ML-KEM / Classic McEliece).
- **Meilenstein 3.2 (HSM & PKI):** Migration der Hardware Security Modules (HSMs) und Vorbereitung langlebiger Root-/Sub-CAs auf hybride bzw. quantensichere Signaturverfahren (XMSS, LMS, ML-DSA, SLH-DSA).

### Phase 4: Decommissioning rein klassischer Public-Key-Verschlüsselung & Audit-Abschluss [Q3 2030 – Q2 2031]
- **Meilenstein 4.1:** Verbindliche Abschaltung rein klassischer Schlüsselaushandlungs-Cipher-Suites in TLS-, IPsec- und SSH-Policies.
- **Meilenstein 4.2:** Abschluss-Audit und Aktualisierung des Verzeichnisses von Verarbeitungstätigkeiten (TOM-Nachweis nach Art. 32 DSGVO) sowie des NIS-2-Kryptographie-Konzepts.

---

## 4. Vorlage für den Vorstands- / Geschäftsleitungs-Beschluss (§ 30 BSIG / NIS-2)

```text
BESCHLUSSVORLAGE DER GESCHÄFTSLEITUNG / IT-SICHERHEITSLEITUNG
-------------------------------------------------------------
Betreff: Verabschiedung des Post-Quanten-Kryptographie-Migrationsplans (2026–2031)
Referenz: BSI TR-02102-1 (Stand 2026), § 30 BSIG (NIS-2), Art. 32 DSGVO

1. Das kryptographische Inventar (Krypto-Inventar-PQC-2031.csv) wird als verbindliches
   Steuerungsdokument für alle IT-Systeme und Eigenentwicklungen eingeführt.
2. Bei Neuanschaffungen von Netzwerk-, VPN-, HSM- und Sicherheitskomponenten ab Q4 2026
   ist die Unterstützung hybrider Post-Quanten-Verfahren nach BSI TR-02102 Pflichtkriterium.
3. Die Umsetzung der 4-Phasen-Roadmap bis Ende 2030 (Puffer vor der BSI-Frist 2031)
   wird genehmigt und halbjährlich durch den CISO an die Geschäftsleitung berichtet.

Ort, Datum: _______________________   Unterschrift Geschäftsleitung: _______________________
```
